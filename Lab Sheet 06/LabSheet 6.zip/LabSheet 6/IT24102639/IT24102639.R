setwd("C:\\Users\\Sulochana\\OneDrive\\Desktop\\LabSheet 6\\IT24102639")
getwd()

##Exercise
#Q1
#Part 1
#Binominal Distribution
#Random variable x has bionominal distribution with n=50 and p= 0.85
#Part 2
dbinom (47, 50,0.85)
#Q2
#Part 1
#Number of customer calls per hour
#part 2
#Poison distribution
#random variable x has poisson distribution with lambda=12
#part 3
dpois(12,15)